# # Bike Share Analysis 🚲
## Submission Analisis Data Dicoding
Streamlit Cloud: https://bike-share-analysis-project-mkhz5uxadszgw4efxjrrus.streamlit.app/ 
## Installation

Clone repository:
```sh
https://github.com/ZulfahBintiToyibah/bike-share-analysis-project
```
Install pustaka:

```sh
pip install -r requirements.txt
```
## Run Dashboard
```sh
cd dashboard
streamlit run dashboard.py
```
